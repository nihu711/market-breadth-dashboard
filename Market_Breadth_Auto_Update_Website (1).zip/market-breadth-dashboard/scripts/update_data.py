import io, json, math, re, sys
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
import requests
import yfinance as yf
from bs4 import BeautifulSoup

OUT = Path(__file__).resolve().parents[1] / "data.json"
UA={"User-Agent":"Mozilla/5.0 market-breadth-dashboard/1.0"}

def get_sp500_symbols():
    tables=pd.read_html("https://en.wikipedia.org/wiki/List_of_S%26P_500_companies")
    syms=tables[0]["Symbol"].astype(str).str.replace(".","-",regex=False).tolist()
    return syms

def download_prices(symbols):
    # 1 year is enough for 200DMA plus 52-week high/low context.
    px=yf.download(symbols,period="1y",interval="1d",auto_adjust=True,progress=False,
                   group_by="column",threads=True)
    close=px["Close"] if isinstance(px.columns,pd.MultiIndex) else px
    return close.dropna(axis=1,how="all")

def calc_breadth(close):
    latest=close.ffill().iloc[-1]
    ma20=close.rolling(20,min_periods=20).mean().iloc[-1]
    ma50=close.rolling(50,min_periods=50).mean().iloc[-1]
    ma200=close.rolling(200,min_periods=200).mean().iloc[-1]
    valid=latest.notna()
    def pct_above(ma):
        v=valid & ma.notna()
        return round(float((latest[v]>ma[v]).mean()*100),1)
    # New 52-week high/low using prior 252 sessions where available.
    win=close.tail(min(252,len(close)))
    hi=win.max(); lo=win.min()
    tol=.001
    new_hi=int(((latest >= hi*(1-tol)) & valid).sum())
    new_lo=int(((latest <= lo*(1+tol)) & valid).sum())
    ratio=round(new_hi/new_lo,2) if new_lo else (9.99 if new_hi else 1.0)
    return pct_above(ma20), pct_above(ma50), pct_above(ma200), new_hi, new_lo, ratio, str(close.index[-1].date())

def get_vix():
    u="https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv"
    df=pd.read_csv(u)
    df.columns=[c.strip().upper() for c in df.columns]
    row=df.iloc[-1]
    return float(row["CLOSE"]), str(pd.to_datetime(row["DATE"]).date())

def get_put_call():
    # Cboe publishes a daily ratios table. Try the current page and parse "TOTAL PUT/CALL RATIO".
    u="https://www.cboe.com/markets/us/options/market-statistics/daily/"
    r=requests.get(u,headers=UA,timeout=30); r.raise_for_status()
    text=BeautifulSoup(r.text,"html.parser").get_text(" ",strip=True)
    m=re.search(r"TOTAL PUT/CALL RATIO\s+([0-9]+\.[0-9]+)",text,re.I)
    if not m: return None
    return float(m.group(1))

def score(b20,b50,b200,hl,vix,pc):
    shl=max(0,min(100,(hl/2)*100))
    svix=max(0,min(100,100-((vix-10)/30)*100))
    spc=50 if pc is None else max(0,min(100,100-((pc-.5)/1.0)*100))
    return round(b200*.28+b50*.28+b20*.14+shl*.12+svix*.10+spc*.08)

def main():
    previous={}
    if OUT.exists():
        try: previous=json.loads(OUT.read_text())
        except: pass
    syms=get_sp500_symbols()
    close=download_prices(syms)
    b20,b50,b200,nh,nl,hl,price_date=calc_breadth(close)
    vix,vix_date=get_vix()
    try: pc=get_put_call()
    except Exception as e:
        print("Put/call warning:",e,file=sys.stderr)
        pc=previous.get("put_call")
    asof=max(price_date,vix_date)
    data={
      "as_of":asof,
      "updated_at":datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
      "above_20d":b20,"above_50d":b50,"above_200d":b200,
      "new_highs":nh,"new_lows":nl,"high_low_ratio":hl,
      "vix_close":round(vix,2),"put_call":pc,
      "score":score(b20,b50,b200,hl,vix,pc),
      "universe_count":int(close.shape[1])
    }
    OUT.write_text(json.dumps(data,indent=2))
    print(json.dumps(data,indent=2))
if __name__=="__main__": main()
