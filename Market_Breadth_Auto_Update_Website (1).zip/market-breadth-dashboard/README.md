# Market Sentiment & Breadth Dashboard

A static GitHub Pages dashboard that refreshes after the U.S. market close.

## What updates
- S&P 500 % above 20-day, 50-day, 200-day moving averages
- S&P 500 52-week new highs / new lows
- Cboe VIX daily close
- Cboe total put/call ratio when the public daily page can be parsed
- Composite 0-100 sentiment score

## Publish
1. Create a new GitHub repository.
2. Upload all files/folders from this package to the repository root.
3. In GitHub: Settings -> Pages.
4. Under "Build and deployment", choose "Deploy from a branch".
5. Branch: `main`, folder: `/ (root)`, then Save.
6. In GitHub: Actions -> "Update market breadth" -> Run workflow once.
7. Bookmark the GitHub Pages URL.

The workflow then runs every weekday at 21:20 UTC (5:20 PM ET during daylight saving time).

## Notes
The stock breadth measures are computed from current S&P 500 constituents using Yahoo Finance daily price data. VIX comes from Cboe's daily VIX history CSV. Put/call is parsed from Cboe's daily market statistics page; if that parse temporarily fails, the last successfully stored value remains in `data.json`.
